from django.db import models # type: ignore

# Create your models here.
#  create a company model

class Company(models.Model):
    comp_id = models.AutoField(primary_key=True)
    comp_name = models.CharField(max_length=50)
    comp_location=models.CharField(max_length=50)
    comp_about=models.TextField()
    comp_type=models.CharField(max_length=100,choices=(("it","it"),
                                                      ("non-it","non-it"),
                                                      ("owner","owner")
                                                      ))
    comp_added_date=models.DateTimeField(auto_now=True)
    comp_active=models.BooleanField(default=True)
    def __str__(self):
        return self.comp_name + self.comp_location

# realtions  one to manay 
#  employee model
class Employee(models.Model):
    emp_name = models.CharField(max_length=100)
    emp_email=models.CharField(max_length=50)
    emp_address=models.CharField(max_length=200)
    emp_phone=models.CharField(max_length=10)
    emp_about=models.TextField()
    emp_position=models.CharField(max_length=50,choices=(
        ('Manager','manager'),
        ("Software","s/w"),
        ('Project Leader','pl')
    ))

    company=models.ForeignKey(Company,on_delete=models.CASCADE)