from django.shortcuts import render,HttpResponse
from rest_framework import viewsets
from api.models import Company,Employee
from api.serializers import CompanySerializer,EmployeeSerializer
from rest_framework.decorators import action
from rest_framework.response import Response


# Create your views here.
def home_page(request):
    # friends=[
    #     'amit',
    #     'ankit',
    #     'mohan'
    # ]
    return render(request,'home.html')
    # return JsonResponse(friends,safe=False)

class CompanyViewSet(viewsets.ModelViewSet):
    queryset=Company.objects.all()
    serializer_class=CompanySerializer

    @action(detail=True,methods=['get'])
    def employees(self,request,pk=None):
        # print(f" get employee of {pk} company")
        try:
            company=Company.objects.get(pk=pk)
            emps=Employee.objects.filter(company=company)
            emp_serializer=EmployeeSerializer(emps,many=True,context={'request':request})
            return Response(emp_serializer.data)
        except Exception as e:
            print(e)
            return Response({
                "message":"Copmany might not extst  !! Error "

            })

class EmployeeViewSet(viewsets.ModelViewSet):
    queryset=Employee.objects.all()
    serializer_class=EmployeeSerializer
