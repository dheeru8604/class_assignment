from django.contrib import admin

from .models import Company, Employee




# Register your models here.

class CompanyAdmin(admin.ModelAdmin):
    list_display=('comp_name','comp_location','comp_type')
# searchfield 
    search_fields=('comp_name',)

class EmployeeAdmin(admin.ModelAdmin):
    list_display=('emp_name','emp_email','emp_address')
# filter Company
    list_filter=('company',)
    
admin.site.register(Company,CompanyAdmin)
admin.site.register(Employee,EmployeeAdmin)
