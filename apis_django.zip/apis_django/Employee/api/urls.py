from django.contrib import admin
from django.urls import path,include
from rest_framework import routers
# router view set add and mapping
from api.views import CompanyViewSet,EmployeeViewSet, home_page


router = routers.DefaultRouter()
router.register(r"companies",CompanyViewSet)
router.register(r'employee',EmployeeViewSet)

urlpatterns = [
    path('',include(router.urls)),
    path('home/',home_page),
]

# companies/{companyid}/employess

